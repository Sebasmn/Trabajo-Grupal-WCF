/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Referencias.ArrayOfCategory;
import Referencias.Category;
import Referencias.CategoryService;
import Referencias.ObjectFactory;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBElement;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author franc
 */
public class insertar extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_65031/AppData/Servicios/CategoryService.svc.wsdl")
    private CategoryService service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
            String campo = request.getParameter("campo");
            String id = request.getParameter("IDNueva");
            String sn = request.getParameter("SNNueva");
             String ln = request.getParameter("LNNueva");
             
            int op  = Integer.valueOf(campo);
            switch(op){
                    case 1:
                       
                       
                        
                        try{
                            int r =  insertar(id,sn,ln);
                             if (r!=1) {
                                 request.setAttribute("mensaje","Registro ya existe" );
                           
                                 }else{
                             request.setAttribute("mensaje","Insercion con exito !" );
                                 }
                        }catch(Exception e){
                            request.setAttribute("mensaje","Registro ya existe" );
                        }
                        
                    break;
                    case 2:
                        
                        actualizar(id,sn,ln);
                        request.setAttribute("mensaje","Actualizacion con exito !" );
                    break;
                    
            }
            
             
             request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

   
    private int insertar(java.lang.String id, java.lang.String sn, java.lang.String ln) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        Referencias.ICategoryService port = service.getBasicHttpBindingICategoryService();
        return port.insertar(id, sn, ln);
    }

    private Integer actualizar(java.lang.String id, java.lang.String sn, java.lang.String ln) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        Referencias.ICategoryService port = service.getBasicHttpBindingICategoryService();
        return port.actualizar(id, sn, ln);
    }

    private Integer borrar(java.lang.String id, java.lang.String sn, java.lang.String ln) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        Referencias.ICategoryService port = service.getBasicHttpBindingICategoryService();
        return port.borrar(id, sn, ln);
    }
    
    
    
}
