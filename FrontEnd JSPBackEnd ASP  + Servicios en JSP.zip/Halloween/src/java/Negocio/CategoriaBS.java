/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import AccesoDatos.CategoriaAD;
import Entidades.Categoria;
import java.util.ArrayList;

/**
 *
 * @author franc
 */
public class CategoriaBS {
    public CategoriaBS(){
        
    }
    
          public ArrayList<Categoria>  GetCategories() {
          CategoriaAD data = new CategoriaAD();
          return data.GetCategories();
   
          }
          
           public Categoria GetCategoryByID(String id){
                 CategoriaAD data = new CategoriaAD();
                    return data.GetCategoryByID(id);
           }
           
            public int InsertCategory(Categoria category) {
             CategoriaAD data = new CategoriaAD();
                    return data.InsertCategory(category);
            
            }

                 public int InsertCategory(String id, String nombre, String nombreLargo) {
                    CategoriaAD data = new CategoriaAD();
                    return data.InsertCategory(id,nombre,nombreLargo);
    }

    public int UpdateCategory(Categoria categoria) {
                         CategoriaAD data = new CategoriaAD();
                    return data.UpdateCategory(categoria);
    }
    
    
    public Integer UpdateCategoryTextos(String CategoryID,String ShortName, String LongName) {
                    CategoriaAD data = new CategoriaAD();
                    return data.UpdateCategoryTextos(CategoryID,ShortName,LongName);
    }

    public Integer DeleteCategory(String CategoryID) {
        CategoriaAD data = new CategoriaAD();
                    return data.DeleteCategory(CategoryID);
    }
}
