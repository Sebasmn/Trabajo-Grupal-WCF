/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import AccesoDatos.CategoriaAD;
import javax.jws.WebService;
import javax.jws.WebMethod;
import Entidades.Categoria;
import Negocio.CategoriaBS;
import java.util.ArrayList;
import javax.jws.WebParam;

/**
 *
 * @author franc
 */
@WebService(serviceName = "CategoryService")
public class CategoryService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "GetCategories")
    public ArrayList<Categoria>  GetCategories() {
          CategoriaBS data = new CategoriaBS();
          return data.GetCategories();
   
    }
    
    @WebMethod(operationName = "GetCategoryByID")
    public Categoria  GetCategoryByID(@WebParam(name = "id") String id) {
          CategoriaBS data = new CategoriaBS();
          return data.GetCategoryByID(id);
   
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "InsertCategory")
    public int InsertCategory(@WebParam(name = "CategoryID") Categoria CategoryID) {
                CategoriaBS data = new CategoriaBS();
                return data.InsertCategory(CategoryID);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Insertar")
    public int  Insertar(@WebParam(name = "id") String id, @WebParam(name = "nombre") String nombre, @WebParam(name = "nombreLargo") String nombreLargo) {
        //TODO write your implementation code here:
        CategoriaBS data = new CategoriaBS();
                return data.InsertCategory(id,nombre,nombreLargo);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "UpdateCategory")
    public Integer UpdateCategory(@WebParam(name = "Categoria") Categoria categoria) {
          CategoriaBS data = new CategoriaBS();
                return data.UpdateCategory(categoria);
    }
    
    
     public int UpdateCategoryTextos(@WebParam(name = "CategoryID") String CategoryID, @WebParam(name = "ShortName") String ShortName, @WebParam(name = "LongName") String LongName) {
                    CategoriaBS data = new CategoriaBS();
                    return data.UpdateCategoryTextos(CategoryID,ShortName,LongName);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "DeleteCategory")
    public Integer DeleteCategory(@WebParam(name = "CategoryID") String CategoryID) {
        CategoriaBS data = new CategoriaBS();
                return data.DeleteCategory(CategoryID);
    }
    
    
    
}
