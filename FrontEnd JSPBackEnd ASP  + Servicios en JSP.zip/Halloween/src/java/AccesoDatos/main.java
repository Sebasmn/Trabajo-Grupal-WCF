/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Entidades.Categoria;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author franc
 */
public class main {
    public static void main(String[] args) {
        
             ArrayList<Categoria> lista  = new ArrayList<Categoria>();   
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://javier\\JAVIER:1433;databaseName=Halloween;user=sa;password=Kenny08**";
            Connection conn =   DriverManager.getConnection(cadena);
            if(conn!=null){
                System.out.println("Conectado"); 
            }
           Statement stmt = conn.createStatement();
            ResultSet rs;
                 
                 rs = stmt.executeQuery("SELECT CategoryID,ShortName,LongName FROM dbo.Categories ");
                 Categoria categoria = new Categoria();
                 while ( rs.next() ) {
                
               categoria.CategoryID = rs.getString("CategoryID");
                categoria.ShortName = rs.getString("ShortName");
                 categoria.LongName = rs.getString("LongName");
                 
                 
                 lista.add(categoria);
            }
            conn.close();
            
             System.out.println(lista.get(1).CategoryID); 
             //lista;
            /*try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDataSource");
            javax.naming.InitialContext ctx = new javax.naming.InitialContext();
            javax.sql.DataSource ds = (javax.sql.DataSource)ctx.lookup("sqlServer");
            java.sql.Connection conn = ds.getConnection();
            return "asd";
            } catch (Exception ex) {
            return "Error";
            }*/
        } catch (Exception ex) {
            System.out.println(ex.getMessage()); 
            //lista;
        }
    }
}
