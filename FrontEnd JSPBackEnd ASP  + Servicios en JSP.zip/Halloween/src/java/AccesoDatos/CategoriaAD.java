/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Entidades.Categoria;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author franc
 */
public class CategoriaAD {
    public CategoriaAD(){
        
    }
    
     public ArrayList<Categoria>  GetCategories() {
          ArrayList<Categoria> lista  = new ArrayList<Categoria>();   
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://javier\\JAVIER:1433;databaseName=Halloween;user=sa;password=Kenny08**";
            Connection conn =   DriverManager.getConnection(cadena);
            if(conn!=null){
                System.out.println("Conectado"); 
            }
           Statement stmt = conn.createStatement();
            ResultSet rs;
                 
                 rs = stmt.executeQuery("SELECT CategoryID,ShortName,LongName FROM dbo.Categories ");
                 
                 while ( rs.next() ) {
                Categoria categoria = new Categoria();
               categoria.CategoryID = rs.getString("CategoryID");
                categoria.ShortName = rs.getString("ShortName");
                 categoria.LongName = rs.getString("LongName");
                 
                 
                 lista.add(categoria);
            }
            conn.close();
            
          
        } catch (Exception ex) {
            
           
        }
        return lista;
   
    }

      public Categoria GetCategoryByID(String id) {
          Categoria categoria  = new Categoria();   
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://javier\\JAVIER:1433;databaseName=Halloween;user=sa;password=Kenny08**";
            Connection conn =   DriverManager.getConnection(cadena);
           
           Statement stmt = conn.createStatement();
            ResultSet rs;
                 
                 rs = stmt.executeQuery("SELECT CategoryID,ShortName,LongName FROM dbo.Categories "
                         + " WHERE CategoryID = '"+id+"'");
                 
                 categoria = new Categoria();
                 while ( rs.next() ) {
               
               categoria.CategoryID = rs.getString("CategoryID");
                categoria.ShortName = rs.getString("ShortName");
                 categoria.LongName = rs.getString("LongName");

            }
                  conn.close();
                 return categoria;
      
          
        } catch (Exception ex) {
            
          // return ex.getMessage();
        }
        return categoria;
   
    }
      
      
      public int InsertCategory(Categoria category) {
          
          Categoria categoria  = new Categoria();   
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://javier\\JAVIER:1433;databaseName=Halloween;user=sa;password=Kenny08**";
            Connection conn =   DriverManager.getConnection(cadena);
           Statement stmt = conn.createStatement();
            int conteo=  stmt.executeUpdate("INSERT INTO dbo.Categories " + 
                "VALUES ("
                    + "'"+category.CategoryID+"'," 
                     + "'"+category.ShortName+"'," 
                     + "'"+category.LongName+"')" 
                    );
                
            conn.close();
            return conteo;
          
        } catch (Exception ex) {
            
           return -1;
        }
        
   
    }

    public int InsertCategory(String id, String nombre, String nombreLargo) {
      Categoria categoria  = new Categoria();   
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://javier\\JAVIER:1433;databaseName=Halloween;user=sa;password=Kenny08**";
            Connection conn =   DriverManager.getConnection(cadena);
           Statement stmt = conn.createStatement();
            int conteo=  stmt.executeUpdate("INSERT INTO dbo.Categories " + 
                "VALUES ("
                    + "'"+id+"'," 
                     + "'"+nombre+"'," 
                     + "'"+nombreLargo+"')" 
                    );
                
            conn.close();
            return conteo;
          
        } catch (Exception ex) {
            
           return  -1;
        }
    }

    public Integer UpdateCategory(Categoria categoria) {
         try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://javier\\JAVIER:1433;databaseName=Halloween;user=sa;password=Kenny08**";
            Connection conn =   DriverManager.getConnection(cadena);
           Statement stmt = conn.createStatement();
            int conteo=  stmt.executeUpdate("UPDATE  dbo.Categories " + 
                "SET  ShortName='"+categoria.ShortName+"',"
                        + "LongName="+ "'"+categoria.LongName+"'"
                             + " WHERE CategoryID='"
                                + categoria.CategoryID+"'");
                
            conn.close();
            return conteo;
          
        } catch (Exception ex) {
            
           return  -1;
        }
    }
    
    
    
      public int UpdateCategoryTextos(String CategoryID,String ShortName, String LongName) {
         try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://javier\\JAVIER:1433;databaseName=Halloween;user=sa;password=Kenny08**";
            Connection conn =   DriverManager.getConnection(cadena);
           Statement stmt = conn.createStatement();
            int conteo=  stmt.executeUpdate("UPDATE  dbo.Categories " + 
                "SET  ShortName='"+ShortName+"',"
                        + "LongName="+ "'"+LongName+"'"
                             + " WHERE CategoryID='"
                                + CategoryID+"'");
                
            conn.close();
            return conteo;
          
        } catch (Exception ex) {
            
           return  -1;
        }
    }

    public Integer DeleteCategory(String CategoryID) {
          try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://javier\\JAVIER:1433;databaseName=Halloween;user=sa;password=Kenny08**";
            Connection conn =   DriverManager.getConnection(cadena);
           Statement stmt = conn.createStatement();
            int conteo=  stmt.executeUpdate("DELETE FROM dbo.Categories WHERE CategoryID='"+CategoryID+"'");
                
            conn.close();
            return conteo;
          
        } catch (Exception ex) {
            
           return  -1;
        }
   
    }
}
