﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace HalloweenStore.AppData.Entidades
{
    [DataContract]
    public class Category
    {
        [DataMember]
        public string CategoryID { get; set; }
        [DataMember]
        public string ShortName { get; set; }
        [DataMember]
        public string LongName { get; set; }
    }
}