﻿using HalloweenStore.AppData.AccesoDatos;
using HalloweenStore.AppData.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.Services.Description;
using System.Windows.Forms;

namespace HalloweenStore.AppData.ReglasNegocio
{
    public class CategoryLogic
    {
        private CategoryAD data;
        public CategoryLogic()
        {
            data = new CategoryAD();
        }
        /// <summary>
        /// Obtener categorias
        /// </summary>
        /// <returns></returns>
        public List<Category> GetCategories()
        {
            return data.GetCategories();
        }
        /// <summary>
        /// Devolver categoria por ID
        /// </summary>
        /// <returns></returns>
        public Category GetCategoryById(string id)
        {
            return data.GetCategoryById(id);
        }
        /// <summary>
        /// Insertar una categoria
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        public int InsertCategory(Category category)
        {
            return data.InsertCategory(category);
        }
        /// <summary>
        /// Actualizar una categoria
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        public int UpdateCategory(Category category)
        {
            return data.UpdateCategory(category);
        }
        /// <summary>
        /// Eliminar una categoria
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        public int DeleteCategory(Category category)
        {
            try
            {
              
                if (   data.DeleteCategory(category) > 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception e)
            {

                return -1;
              
            }
           
        }

        public int Borrar(string id, string sn, string ln)
        {
             return data.Borrar(id, sn, ln);
         /*return data.Borrar(id, sn, ln);
         return data.Actualizar(id, sn, ln);*/
        }

        public int Actualizar(string id, string sn, string ln)
        {
            return data.Actualizar(id, sn, ln);
        }

        public  int Insertar(string id, string sn, string ln)
        {
            return data.Insertar(id, sn, ln);
        }
    }
}