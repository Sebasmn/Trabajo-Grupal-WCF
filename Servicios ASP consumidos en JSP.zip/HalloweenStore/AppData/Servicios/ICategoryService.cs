﻿using HalloweenStore.AppData.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HalloweenStore.AppData.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "ICategoryService" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface ICategoryService
    {
        [OperationContract]
        List<Category> GetCategoriesService();
        [OperationContract]
        Category GetCategoryByIdService(string id);
        [OperationContract]
        int InsertCategoriesService(Category category);
        [OperationContract]
        int DeleteCategoriesService(Category category);
        [OperationContract]
        int UpdateCategoriesService(Category category);
        //SOLO STRINGS
        [OperationContract]
        int Insertar(string id, string sn, string ln);

        [OperationContract]
        int Actualizar(string id, string sn, string ln);

        [OperationContract]
        int Borrar(string id, string sn, string ln);
    }
}
