﻿using HalloweenStore.AppData.Entidades;
using HalloweenStore.AppData.ReglasNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HalloweenStore.AppData.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "CategoryService" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione CategoryService.svc o CategoryService.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class CategoryService : ICategoryService
    {
        //Clase de la Capa de Negocio
        private CategoryLogic data;

        public CategoryService()
        {
            data = new CategoryLogic();
        }

        public int DeleteCategoriesService(Category category)
        {
            try
            {
                return data.DeleteCategory(category);
            }
            catch (Exception)
            {

                return -1;
            }
         
        }

        public Category GetCategoryByIdService(string id)
        {
            try
            {
                return data.GetCategoryById(id);
            }
            catch (Exception)
            {

                return null;
            }

        }



        public List<Category> GetCategoriesService()
        {
            ///Llamar a metodos de la capa de Negocio o de DAL
            return data.GetCategories();
        }

        public int InsertCategoriesService(Category category)
        {
            try
            {
                return data.InsertCategory(category);
            }
            catch (Exception)
            {

                return -1;
            }

        }

        public int UpdateCategoriesService(Category category)
        {
            try
            {
                return data.UpdateCategory(category);
            }
            catch (Exception)
            {

                return -1;
            }
        }

        int ICategoryService.DeleteCategoriesService(Category category)
        {
            try
            {
                return data.DeleteCategory(category);
            }
            catch (Exception)
            {

                return -1;
            }
        }

        public int Insertar( string id, string sn, string ln)
        {
            return data.Insertar(id, sn, ln);
           /* return data.Borrar(id, sn, ln);
            return data.Actualizar(id, sn, ln);*/
        }

        public int Actualizar(string id, string sn, string ln)
        {
            return data.Actualizar(id, sn, ln);
        }

        public int Borrar(string id, string sn, string ln)
        {
            return data.Borrar(id, sn, ln);
        }
    }
}
